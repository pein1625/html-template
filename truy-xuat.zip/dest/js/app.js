// menu toggle
$(function () {
  $(".menu-toggle").on("click", function () {
    var $toggle = $(this);

    $toggle.toggleClass("active").siblings(".menu-sub").slideToggle();

    $toggle.siblings(".menu-mega").children(".menu-sub").slideToggle();

    $toggle.parent().siblings(".menu-item-group").children(".menu-sub").slideUp();

    $toggle.parent().siblings(".menu-item-group").children(".menu-mega").children(".menu-sub").slideUp();

    $toggle.parent().siblings(".menu-item-group").children(".menu-toggle").removeClass("active");
  });

  $(".menu-item-group > .menu-link, .menu-item-mega > .menu-link").on("click", function (e) {
    if ($(window).width() < 1200 || !mobileAndTabletCheck()) return;

    e.preventDefault();
  });
});

// navbar mobile toggle
$(function () {
  var $body = $("html, body");
  var $navbar = $(".js-navbar");
  var $navbarToggle = $(".js-navbar-toggle");

  $navbarToggle.on("click", function () {
    $navbarToggle.toggleClass("active");
    $navbar.toggleClass("is-show");
    $body.toggleClass("overflow-hidden");
  });
});

$(function () {
  var $moveTop = $(".btn-movetop");
  var $window = $(window);
  var $body = $("html");

  if (!$moveTop.length) return;

  $window.on("scroll", function () {
    if ($window.scrollTop() > 150) {
      $moveTop.addClass("show");

      return;
    }

    $moveTop.removeClass("show");
  });

  $moveTop.on("click", function () {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "smooth"
    });
  });
});

// swiper template
function addSwiper(selector, options = {}) {
  return Array.from(document.querySelectorAll(selector), function (item) {
    var $sliderContainer = $(item),
        $sliderEl = $sliderContainer.find(selector + "__container");

    if (options.navigation) {
      $sliderContainer.addClass("has-nav");
      options.navigation = {
        prevEl: $sliderContainer.find(selector + "__prev"),
        nextEl: $sliderContainer.find(selector + "__next")
      };
    }

    if (options.pagination) {
      $sliderContainer.addClass("has-pagination");
      options.pagination = {
        el: $sliderContainer.find(selector + "__pagination"),
        clickable: true
      };
    }

    return new Swiper($sliderEl, options);
  });
}

$(function () {
  addSwiper('.source-slider', {
    loop: true,
    navigation: true,
    spaceBetween: 16,
    speed: 500,
    slidesPerView: 2,
    breakpoints: {
      576: {
        slidesPerView: 3
      },
      768: {
        slidesPerView: 4
      },
      992: {
        slidesPerView: 5
      },
      1200: {
        slidesPerView: 6
      }
    }
  });
});

$(function () {
  const videoThumbSlider = addSwiper('.video-thumb-slider', {
    slidesPerView: 3,
    spaceBetween: 10,
    navigation: true,
    speed: 400,
    breakpoints: {
      576: {
        slidesPerView: 3,
        spaceBetween: 16
      }
    }
  })[0];

  const videoSlider = addSwiper('.video-slider', {
    speed: 400,
    thumbs: {
      swiper: videoThumbSlider
    }
  })[0];
});

$(function () {
  addSwiper('.banner-slider', {
    effect: 'fade',
    speed: 800,
    pagination: true,
    navigation: true,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    }
  });
});

$(function () {
  addSwiper('.banner-slider-2', {
    speed: 800,
    pagination: true,
    navigation: true,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    }
  });
});

$(function () {
  addSwiper('.banner-slider-3', {
    speed: 800,
    pagination: true,
    navigation: true,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    }
  });
});

// horizontal preview sync slider
$(function () {
  if (!$(".preview-slider, .thumb-slider").length) {
    return;
  }

  if (!window.addSwiper) {
    console.warn('"addSwiper" funtion is required!');
    return;
  }

  var thumbSlider = addSwiper(".thumb-slider", {
    navigation: true,
    slidesPerView: 3,
    freeMode: true,
    spaceBetween: 12,
    watchSlidesProgress: true,
    watchSlidesVisibility: true
  })[0];

  addSwiper(".preview-slider", {
    effect: "fade",
    allowTouchMove: false,
    thumbs: {
      swiper: thumbSlider
    }
  });
});

$(function () {
  addSwiper('.product-slider', {
    navigation: true,
    loop: true,
    speed: 400,
    slidesPerView: 2,
    breakpoints: {
      768: {
        slidesPerView: 3
      },
      992: {
        slidesPerView: 4
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 14
      }
    }
  });
});

$(function () {
  addSwiper('.news-slider', {
    navigation: true,
    spaceBetween: 16,
    speed: 400,
    loop: true,
    breakpoints: {
      768: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 30
      },
      1200: {
        slidesPerView: 3,
        spaceBetween: 30
      }
    }
  });
});

$(function () {
  addSwiper('.news-slider-2', {
    navigation: true,
    spaceBetween: 16,
    speed: 400,
    loop: true,
    breakpoints: {
      768: {
        slidesPerView: 3
      },
      992: {
        slidesPerView: 4
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 30
      }
    }
  });
});

$(function () {

  $('.footer__redirect').on('change', function () {

    let val = $(this).val();

    if (val) {

      window.location.href = val;
    }
  });
});

$(function () {

  const $window = $(window);

  const $header = $('.header');

  $window.on('scroll', function () {

    let offset = 35;

    if ($window.width() >= 1200) {

      offset = 131;
    }

    if ($window.scrollTop() > offset) {

      $header.addClass('is-fixed');
    } else {

      $header.removeClass('is-fixed');
    }
  });
});